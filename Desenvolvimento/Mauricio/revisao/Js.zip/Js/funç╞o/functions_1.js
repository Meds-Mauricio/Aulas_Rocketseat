//function expression
//funtion anonymous

//parâmetros (parameters)
const sum = function(number1, number2) {
console.log(number1 + number2)
}

sum(2, 3) // arguments - argumentos

let name = 'Mauricio'