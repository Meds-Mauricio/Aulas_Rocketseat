
//function expression
//funtion anonymous

//parâmetros (parameters)

 /*const sum = function(number1, number2){
    console.log(number1 + number2)
}
    
    sum(2, 3) */


    /*console.log('aula sobre functions')*/
   
     // criar um aplicativo de frases motivacionais
    //  

// exercicios//

//1. declarando variável de nome weigth
//let weight


// 2. que tipo de dado é a variavel acima?
//console.log(typeof weight)

/* 3. Declare uma variavel e atribua  valaores para cada um dos dados:
*nome: string
*age:  Number (intger)
*stars: Number (float)
*isSubscribed: Boolean

*/

// let name = "mayk"
// let age = 23
// let star = 4.8
// let isSubscribet = false 

// a variavel studant abaixo é d que tipo de dado?

//atribuir os mesmos valores que no exercicio 3;

//  let student = {
//     name: "mayk",
//     age: 23,
//     weight: 74.8,
//     isSubscribed: true,
// }

//   console.log('${student.name} de idade ${student.age} pesa ${student.weigth} kg.')

//declare uma variavel tipo array, sem valores;

//let student = []

// atribuir valor a variavel acima;

// students = [
//     student
// ]
 
// console.log(students)


//Criar um app de frases motivacionais

// declaração da fução

function createPhrases() {
    console.log(' Estudar é muito bom')
    console.log('Paciência e persistencia')
    console.log('revisão é mãe do apendrizado')
}

//execultar funcão
//rodar, chamar, invocar
//execut, run, call, invoke

createPhrases()
createPhrases()
createPhrases()

console.log('fim do programa')