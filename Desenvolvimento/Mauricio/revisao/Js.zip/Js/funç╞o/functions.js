//function expression
//function anonymous

//parametrod (paramers) da fonção
// const sum = function (number1, number2){
// // console.log(number1 + number2)
// return total
// }


// //sum(2, 3) // arguments( argumentos) onde se manda execultar as funçoes

// let number1 = 34
// let number2 = 25
// // sum(number1, number2)

// console.log('o numero 1 é ${number1}')
// console.log('o number 2 é ${number2}')
// console.log('a soma é ${sum(number1, number2)}')
// console.log(total)

//funç~çao de liquidificador

// function fazerSuco(fruta1, fruta2) {
//     return 'suco de: ' + fruta1 + fruta2
// }

// const copo = fazerSuco('banana', 'maça')


// console.log(copo)

//function scope
// let subject = 'create video'

// function createThink() {
//     subject = 'study'
//     return subject
// }

// console.log(subject)
// createThink()
// console.log(subject)


//function hoisting

// sayMyName()

//     function sayMyName() {
//      console.log('mayk')
//  }


//arrow function 

// const sayMyName = () => {
//     console.log(name)
// }

// sayMyName('mayk')


//callback function

// function sayMyName (name) {
//     console.log('antes de executar a funcao callback')

//     name()

//     console.log('depois de executar a callback')
// }

// sayMyName( ()=> {
//     console.log('estou  em uma callback')
//     }
// )


/*function() constructor
*expressão new
*criar um novo objeto
*this keywork
*/

// function Person() {}


// const mayk = new Person()
// console.log(mayk)function Person() {}


function Person(name) {}
this.name = name
this.walk = function() {
    return this.name +" está andando"
}


const mayk = new Person("mayk")
console.log(mayk)