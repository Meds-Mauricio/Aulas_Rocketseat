# Scope 

* Escopo determina a visibilidade de alguma variavel no JS 


# Block Statement = //declaraçao de bloco

//iniciando um block

{
    //aqui dentro é um bloco e poso colocar qualquer codico

} // aqui fechamos  o bloco

/

O bloco, também criara  um novo escopo. Chamamos de 
`block-scoped`

//var é global e, também local

// hoisting => quando eleva pra cima